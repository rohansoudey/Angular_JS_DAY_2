"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var EmployeeService = (function () {
    function EmployeeService() {
    }
    EmployeeService.prototype.getAllEmployee = function () {
        return [
            { empId: 1001, empName: "Niraj", empSalary: 50000 },
            { empId: 1002, empName: "Shaily", empSalary: 48000 },
            { empId: 1003, empName: "Shweta", empSalary: 58000 },
            { empId: 1004, empName: "saurabh", empSalary: 50850 },
            { empId: 1005, empName: "Rohan", empSalary: 35250 },
            { empId: 1006, empName: "Monuprasad", empSalary: 100000 }
        ];
    };
    return EmployeeService;
}());
EmployeeService = __decorate([
    core_1.Injectable()
], EmployeeService);
exports.EmployeeService = EmployeeService;
//# sourceMappingURL=employee.service.js.map