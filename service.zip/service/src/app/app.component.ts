import { Component } from '@angular/core';
import { EmployeeList } from './app.employeeList';
@Component({
  selector: 'my-app',
  template: `<my-component></my-component>`
})
export class AppComponent  {  

	name="Welcome Angulat 2";

}

