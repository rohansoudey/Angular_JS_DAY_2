import { Injectable} from '@angular/core';
import {IEmployee} from './employee'
@Injectable()

export class EmployeeService{

	getAllEmployee():IEmployee[]
	{
		return[
			{empId:1001,empName:"Niraj",empSalary:50000},
			{empId:1002,empName:"Shaily",empSalary:48000},
			{empId:1003,empName:"Shweta",empSalary:58000},
			{empId:1004,empName:"saurabh",empSalary:50850},
			{empId:1005,empName:"Rohan",empSalary:35250},
			{empId:1006,empName:"Monuprasad",empSalary:100000}
		];
	}

}